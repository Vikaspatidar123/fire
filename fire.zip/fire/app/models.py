from django.db import models

# Create your models here.
class Information(models.Model):
    name=models.CharField(max_length=100)
    
    camera1=models.CharField(max_length=50,default='')
    camera2=models.CharField(max_length=50,default='')
    camera3=models.CharField(max_length=50,default='')
    camera4=models.CharField(max_length=50,default='')

    deca=models.CharField(max_length=50,default='')
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name