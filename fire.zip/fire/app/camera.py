from imutils import video
from imutils.video import VideoStream
import imutils
import cv2
import os
import urllib.request
import numpy as np
from django.conf import settings





class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        self.img_counter = 0
        # fourcc = cv2.VideoWriter_fourcc(*'XVID')
        # self.out = cv2.VideoWriter('output.avi',fourcc, 20.0, (640,480))
        

    def __del__(self):
        self.video.release()
        # self.out.release()


    #This function is used in views
    def get_frame(self):
        

        success, image = self.video.read()
        frame_flip = cv2.flip(image, 1)
        img_name = "opencv_frame_{}.png".format(self.img_counter)
        ret, jpeg = cv2.imencode('.jpg', frame_flip)
        # s=cv2.imwrite('image', image)
        # print(s)
        return jpeg.tobytes()
 


class IPWebCam(object):
    def __init__(self):
        self.url = "http://26.231.247.243:8081/shot.jpg"


    def __del__(self):
        cv2.destroyAllWindows()

    def get_frame(self):
        imgResp = urllib.request.urlopen(self.url)
        imgNp = np.array(bytearray(imgResp.read()), dtype=np.uint8)
        img = cv2.imdecode(imgNp, -1)
        img =cv2.resize(img, (640, 480))
        frame_flip = cv2.flip(img, 1)
        ret, jpeg = cv2.imencode('.jpg', frame_flip)
        return jpeg.tobytes()



