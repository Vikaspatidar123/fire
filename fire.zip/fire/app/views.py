from app.models import Information
from django.views.decorators import gzip
from django.shortcuts import redirect, render
from django.http import StreamingHttpResponse
from django.contrib.auth.models import User
import cv2
import threading
import datetime
from app.camera import VideoCamera ,IPWebCam
def home(request):
    	return render(request, '2.html')
def index(request):
    	
	all=request.user
	a=User.objects.get(username=all)
	print(a)
	return render(request, '1.html',{'now':all})

#Every time you call the phone and laptop camera method gets frame
#More info found in camera.py
def gen(camera):
	while True:
		frame = camera.get_frame()
		yield (b'--frame\r\n'
				b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

#Method for laptop camera
def video_feed(request):
    
	# k=request.POST.get('options1')
	return StreamingHttpResponse(gen(VideoCamera()),
                    #video type
					content_type='multipart/x-mixed-replace; boundary=frame')

#Method for phone camera
def webcam_feed(request):
	return StreamingHttpResponse(gen(IPWebCam()),
                    #video type
					content_type='multipart/x-mixed-replace; boundary=frame')

def Desk(request):
    	
	name=request.user
	all=Information.objects.all()
	print(all)

	return render(request,'desk.html',{'all':all,'name':name})

def Show(request):
	if request.method=='POST':
    	
		camera1=request.POST.get('options1')
		camera2=request.POST.get('options2')
		camera3=request.POST.get('options3')
		camera4=request.POST.get('options4')
		name=request.user
		a=Information(name=name,camera1=camera1,camera2=camera2,camera3=camera3,camera4=camera4)
		a.save()
		print(camera1,camera2,camera3,camera4,name)
		all=name
		print(all)

		return redirect('index')
		# print(pk)
