
from django.urls import path
from .import views

urlpatterns = [
    path('',views.home),
    path('index', views.index, name='index'),
    path('desk',views.Desk,name="Desk"),
    path('show',views.Show),
    

    #access the laptop camera
    path('video_feed', views.video_feed, name='video_feed'),

    #access the phone camera
    path('webcam_feed', views.webcam_feed, name='webcam_feed'),
]
